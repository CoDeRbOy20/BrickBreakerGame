package com.example.brickbreaker;

import com.example.brickbreaker.elements.Ball;
import com.example.brickbreaker.elements.Brick;
import com.example.brickbreaker.elements.Paddle;
import javafx.animation.AnimationTimer;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

import java.util.ArrayList;
import java.util.List;

public class BrickBreakerGame {
    private static final int SCENE_WIDTH = 600;
    private static final int SCENE_HEIGHT = 400;

    private Paddle paddle;
    private Ball ball;
    private List<Brick> bricks;

    public void start(Stage primaryStage) {

        paddle = new Paddle(SCENE_WIDTH / 2 - 50, SCENE_HEIGHT - 20, 100, 10);
        ball = new Ball(SCENE_WIDTH / 2, SCENE_HEIGHT / 2, 5);
        bricks = new ArrayList<>();


        for (int i = 0; i < 10; i++) {
            for (int j = 0; j < 5; j++) {
                Brick brick = new Brick(60 * i, 30 * j, 50, 20);
                bricks.add(brick);
            }
        }


        Group root = new Group();
        root.getChildren().add(paddle.getPaddleShape());
        root.getChildren().add(ball.getBallShape());
        for (Brick brick : bricks) {
            root.getChildren().add(brick.getBrickShape());
        }


        Scene scene = new Scene(root, SCENE_WIDTH, SCENE_HEIGHT, Color.BLACK);
        primaryStage.setScene(scene);
        primaryStage.setTitle("Brick Breaker Game");
        primaryStage.show();


        AnimationTimer timer = new AnimationTimer() {
            @Override
            public void handle(long now) {
                update();
            }
        };
        timer.start();
    }

    private void update() {
        ball.updatePosition();

    }
}
