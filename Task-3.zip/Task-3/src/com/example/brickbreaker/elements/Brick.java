package com.example.brickbreaker.elements;

import javafx.scene.shape.Rectangle;

public class Brick {
    private Rectangle brickShape;
    private double x, y;
    private double width, height;

    public Brick(double x, double y, double width, double height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.brickShape = new Rectangle(x, y, width, height);
    }

    public Rectangle getBrickShape() {
        return brickShape;
    }
}
