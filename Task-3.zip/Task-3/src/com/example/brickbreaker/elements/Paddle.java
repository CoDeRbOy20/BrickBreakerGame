package com.example.brickbreaker.elements;

import javafx.scene.shape.Rectangle;

public class Paddle {
    private Rectangle paddleShape;
    private double x, y;
    private double width, height;

    public Paddle(double x, double y, double width, double height) {
        this.x = x;
        this.y = y;
        this.width = width;
        this.height = height;
        this.paddleShape = new Rectangle(x, y, width, height);
    }

    public Rectangle getPaddleShape() {
        return paddleShape;
    }

    public void move(double dx) {
        x += dx;
        paddleShape.setX(x);
    }
}
