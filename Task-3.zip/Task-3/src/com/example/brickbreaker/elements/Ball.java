package com.example.brickbreaker.elements;

import javafx.scene.shape.Circle;

public class Ball {
    private Circle ballShape;
    private double x, y;
    private double radius;
    private double dx, dy;

    public Ball(double x, double y, double radius) {
        this.x = x;
        this.y = y;
        this.radius = radius;
        this.dx = 1;
        this.dy = -1;
        this.ballShape = new Circle(x, y, radius);
    }

    public Circle getBallShape() {
        return ballShape;
    }

    public void updatePosition() {
        x += dx;
        y += dy;
        ballShape.setCenterX(x);
        ballShape.setCenterY(y);
    }
}
